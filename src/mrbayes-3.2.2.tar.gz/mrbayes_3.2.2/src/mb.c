// char version[]="$Id: mb.c,v3.2 2013/_/_ Exp $";
const char* const svnRevisionMbC="$Rev: 652 $";   /* Revision keyword which is expanded/updated by svn on each commit/update */
